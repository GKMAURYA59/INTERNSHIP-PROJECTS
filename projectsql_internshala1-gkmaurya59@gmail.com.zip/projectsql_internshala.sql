create database projectsql;
use projectsql;
SELECT * FROM projectsql.fedex_shipments;
SELECT * FROM projectsql.fedex_delivery_agents;
SELECT * FROM projectsql.fedex_orders;
SELECT * FROM projectsql.fedex_shipments;
SELECT * FROM projectsql.fedex_warehouses;

SELECT COUNT(Shipment_ID) AS Total_On_Time_Deliveries
FROM fedex_shipments
WHERE Delivery_Status = 'Delivered';

SELECT
    COUNT(*) AS Total_Deliveries,
    SUM(CASE WHEN Delay_Hours <= 0.5 THEN 1 ELSE 0 END) AS On_Time_Deliveries from fedex_shipments;
    
    SELECT
    SUM(CASE WHEN Delay_Hours <= 0.5 THEN 1 ELSE 0 END) AS On_Time_Deliveries,
    COUNT(*) AS Total_Deliveries,
    ROUND(
        COUNT(CASE WHEN Delivery_Status = 'Delivered' THEN 1 END) * 100.0
        / COUNT(*),
        2
    ) AS On_Time_Delivery_Percentage
FROM fedex_shipments;
Select Route_ID, round(avg(Delay_Hours),2) as Average_Delay_Hours from fedex_shipments group by Route_ID order by Route_ID ASC;
select order_id, count(*) from fedex_orders group by order_id having count(*) > 1;
select shipment_id, count(*)from fedex_shipments group by shipment_id having count(*) > 1;

select date_format(pickup_date, '%y-%m-%d %h:%i:%s') as formatted_pickup_date,    date_format(delivery_date, '%y-%m-%d %h:%i:%s') as formatted_delivery_date from fedex_shipments;
select date_format(order_date, '%y-%m-%d %h:%i:%s') from fedex_orders;

select  route_id,  avg(timestampdiff(hour, pickup_date, delivery_date)) as avg_delay_hours from fedex_shipments group by route_id order by avg_delay_hours desc limit 10;
select     shipment_id,    warehouse_id,    route_id,    timestampdiff(hour, pickup_date, delivery_date) as delay_hours,        rank() over (        partition by warehouse_id        order by timestampdiff(hour, pickup_date, delivery_date) desc    ) as delay_rank from fedex_shipments;
select route_id,avg(timestampdiff(hour, pickup_date, delivery_date)) as avg_transit_time_hours from fedex_shipments group by route_id order by avg_transit_time_hours desc;

select  r.route_id, round(avg(r.distance_km), 2) as avg_distance_km, avg(   timestampdiff( hour, s.pickup_date, s.delivery_date )  ) as avg_transit_time_hours,    round(        avg(r.distance_km) /        avg(            timestampdiff(                hour,   s.pickup_date, s.delivery_date            )        ),        2    ) as distance_to_time_efficiency_ratio from fedex_routes r join fedex_shipments s    on r.route_id = s.route_id group by r.route_id;

select     r.route_id,    round(avg(r.distance_km), 2) as avg_distance_km,    round(        avg(            timestampdiff(                hour,                s.pickup_date,                s.delivery_date            )        ),        2    ) as avg_transit_time_hours,    round(        avg(r.distance_km) /        avg(            timestampdiff(                hour,                s.pickup_date,                s.delivery_date            )        ),        2    ) as efficiency_ratio from fedex_routes r  join fedex_shipments s    on r.route_id = s.route_id group by r.route_id order by efficiency_ratio asc limit 3;

select     route_id,    count(*) as total_shipments,    sum(  case  when delay_hours > 0 then 1   else 0  end ) as delayed_shipments, round( sum( case  when delay_hours > 0 then 1  else 0            end        ) * 100.0 / count(*),        2    ) as delay_percentage from fedex_shipments group by route_id having delay_percentage > 20 order by delay_percentage desc;
select     r.route_id,    r.source_country,    r.destination_country,    r.distance_km,    round(        avg(            timestampdiff(hour, s.pickup_date, s.delivery_date)        ),        2    ) as avg_transit_time_hours,    round(        avg(s.delay_hours),        2    ) as avg_delay_hours,    round(        sum(            case                 when s.delay_hours > 0 then 1                else 0            end        ) * 100.0 / count(*),        2    ) as delay_percentage from fedex_routes r join fedex_shipments s    on r.route_id = s.route_id group by     r.route_id,    r.source_country,    r.destination_country,    r.distance_km having     delay_percentage > 20    or avg_delay_hours > 5 order by     delay_percentage desc,    avg_delay_hours desc;
select     w.warehouse_id,    w.manager_name,    round(        avg(s.delay_hours),        2    ) as avg_delay_hours from fedex_warehouses w join fedex_shipments s    on w.warehouse_id = s.warehouse_id group by     w.warehouse_id,    w.manager_name order by avg_delay_hours desc limit 3;
SELECT 
    warehouse_id,
    COUNT(shipment_id) AS total_shipments,
    SUM(CASE
        WHEN delay_hours >= 0 THEN 1
        ELSE 0
    END) AS delayed_shipments
FROM
    fedex_shipment s
GROUP BY warehouse_id
ORDER BY delayed_shipments DESC;

with global_avg as (    select         avg(delay_hours) as global_avg_delay    from fedex_shipments),warehouse_delay as (    select  warehouse_id, avg(delay_hours) as warehouse_avg_delay    from fedex_shipments    group by warehouse_id)select     w.warehouse_id,    w.warehouse_avg_delay,    g.global_avg_delay from warehouse_delay w cross join global_avg g where w.warehouse_avg_delay > g.global_avg_delay order by w.warehouse_avg_delay desc;

select     warehouse_id,    count(shipment_id) as total_shipments,    sum(        case             when delay_hours = 0 then 1            else 0        end    ) as on_time_shipments,    round(        sum(            case                 when delay_hours = 0 then 1                else 0            end        ) * 100.0 / count(shipment_id),        2    ) as on_time_delivery_percentage,    rank() over (        order by         round(            sum(                case                     when delay_hours = 0 then 1                    else 0                end            ) * 100.0 / count(shipment_id),            2        ) desc    ) as warehouse_rank from fedex_shipments group by warehouse_id order by warehouse_rank;

 with agent_performance as (select  route_id,        agent_id,        count(*) as total_shipments,        sum(case when delay_hours <= 0.5 then 1 else 0 end) as on_time_shipments,        round(            100.0 * sum(case when delay_hours <= 0.5 then 1 else 0 end)            / count(*),            2        ) as on_time_percentage    from fedex_shipments    group by route_id, agent_id)select    route_id,    agent_id,    total_shipments,    on_time_shipments,    on_time_percentage,    rank() over (        partition by route_id        order by on_time_percentage desc    ) as agent_rank from agent_performance order by route_id, agent_rank;

SELECT    Agent_ID,    COUNT(*) AS Total_Shipments,    ROUND(        100.0 * SUM(CASE WHEN Delay_Hours <= 1 THEN 1 ELSE 0 END) / COUNT(*),        2    ) AS On_Time_Percentage FROM fedex_shipments GROUP BY Agent_ID HAVING ROUND(        100.0 * SUM(CASE WHEN Delay_Hours <= 1 THEN 1 ELSE 0 END) / COUNT(*),        2       ) < 85 ORDER BY On_Time_Percentage;



SELECT    'Top 5 Agents' AS Agent_Group,    ROUND(AVG(Avg_Rating),2) AS Avg_Rating,    ROUND(AVG(Experience_Years),2) AS Avg_Experience FROM (    SELECT        da.Agent_ID,        da.Avg_Rating,        da.Experience_Years,        AVG(fs.Delivery_Feedback) AS Performance_Score    FROM fedex_shipments fs    JOIN fedex_delivery_agents da        ON fs.Agent_ID = da.Agent_ID    GROUP BY        da.Agent_ID,        da.Avg_Rating,        da.Experience_Years    ORDER BY Performance_Score DESC    LIMIT 5) t UNION ALL SELECT    'Bottom 5 Agents',    ROUND(AVG(Avg_Rating),2),    ROUND(AVG(Experience_Years),2)FROM (    SELECT        da.Agent_ID,        da.Avg_Rating,        da.Experience_Years,        AVG(fs.Delivery_Feedback) AS Performance_Score    FROM fedex_shipments fs    JOIN fedex_delivery_agents da        ON fs.Agent_ID = da.Agent_ID    GROUP BY        da.Agent_ID,        da.Avg_Rating,        da.Experience_Years    ORDER BY Performance_Score ASC    LIMIT 5) b;

select shipment_id, delivery_date as "Latest Delivery Date", delivery_status from fedex_shipments order by Shipment_ID;
SELECT Route_ID, Delivery_Status from fedex_shipments where Delivery_Status in("In Transit","Returned") order by Route_ID;


SELECT    Delay_Reason,    COUNT(*) AS Occurrences FROM fedex_shipments WHERE Delay_Reason IS NOT NULL GROUP BY Delay_Reason  ORDER BY Occurrences DESC;
SELECT    Order_ID,    Shipment_ID,    Route_ID,    Warehouse_ID,    Agent_ID,    Delay_Hours,    Delivery_Status FROM fedex_shipments WHERE Delay_Hours > 120 ORDER BY Delay_Hours DESC;
SELECT    r.Source_Country,    COUNT(s.Shipment_ID) AS Total_Shipments,    ROUND(AVG(s.Delay_Hours), 2) AS Avg_Delivery_Delay_Hours FROM fedex_shipments s JOIN fedex_routes r    ON s.Route_ID = r.Route_ID GROUP BY r.Source_Country ORDER BY Avg_Delivery_Delay_Hours DESC;
SELECT    SUM(CASE WHEN Delay_Hours <= 0.5 THEN 1 ELSE 0 END) AS On_Time_Deliveries,    COUNT(*) AS Total_Deliveries,    ROUND(        COUNT(CASE WHEN Delivery_Status = 'Delivered' THEN 1 END) * 100.0        / COUNT(*),        2    ) AS On_Time_Delivery_Percentage FROM fedex_shipments;

Select Route_ID, round(avg(Delay_Hours),2) as Average_Delay_Hours from fedex_shipments group by Route_ID order by Route_ID ASC;

select    w.warehouse_id,    w.city,    w.country,    w.capacity_per_day,    count(s.shipment_id) as shipments_handled,    round(        (count(s.shipment_id) * 100.0) / w.capacity_per_day,        2    ) as warehouse_utilization_percentage from fedex_warehouses w left join fedex_shipments s    on w.warehouse_id = s.warehouse_id group by    w.warehouse_id,    w.city,    w.country,    w.capacity_per_day order by warehouse_utilization_percentage desc;











